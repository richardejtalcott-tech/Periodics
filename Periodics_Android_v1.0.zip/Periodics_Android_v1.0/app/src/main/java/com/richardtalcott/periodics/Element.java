package com.richardtalcott.periodics;

import java.io.Serializable;

public record Element(int atomicNumber, String symbol, String name, String category, String summary) implements Serializable {}
