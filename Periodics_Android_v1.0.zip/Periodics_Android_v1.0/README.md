# Periodics Android v1.0

A landscape-first Android periodic-table experience with:
- animated 3D-styled atom loading screen
- zoomable and draggable 118-element periodic table
- tappable element cards
- animated element detail pages
- real-world sample placeholder and Explore button

## GitHub build
Upload the **contents** of this folder to the repository root. Open **Actions**, select **Build Periodics APK**, and run it. The workflow pins:
- Java 17
- Gradle 8.13
- Android Gradle Plugin 8.13.2
- compile/target SDK 35
- minimum SDK 26

It runs `clean assembleDebug testDebugUnitTest lintDebug` and uploads `Periodics-debug-apk`.

## Local build
Install JDK 17, Gradle 8.13, and Android SDK 35, then run:

```bash
gradle clean assembleDebug testDebugUnitTest lintDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`
