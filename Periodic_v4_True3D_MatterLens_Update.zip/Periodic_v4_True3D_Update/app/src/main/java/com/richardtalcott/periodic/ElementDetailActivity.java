package com.richardtalcott.periodic;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.widget.FrameLayout;

public final class ElementDetailActivity extends Activity {
    private True3DView gl;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        int n=getIntent().getIntExtra("atomicNumber",8);
        FrameLayout root=new FrameLayout(this);
        gl=new True3DView(this,true,n);
        root.addView(gl,new FrameLayout.LayoutParams(-1,-1));
        root.addView(new ElementHudView(this,ElementData.byNumber(n)),new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }
    @Override protected void onPause(){super.onPause();gl.onPause();}
    @Override protected void onResume(){super.onResume();gl.onResume();}
}
