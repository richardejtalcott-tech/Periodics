#!/usr/bin/env bash
set -euo pipefail

cd "$(git rev-parse --show-toplevel)"
branch="$(git branch --show-current)"

if [ "$branch" != "v3-development" ]; then
  echo "You are on '$branch'. Switch to v3-development first."
  exit 1
fi

patch_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cp -R "$patch_dir/app/." app/
mkdir -p .github/workflows
cp "$patch_dir/.github/workflows/build-v3.yml" .github/workflows/build-v3.yml

git add app .github/workflows/build-v3.yml
git commit -m "Build Periodic v3 visual experience" || true
git push origin v3-development

echo
echo "Periodic v3 pushed successfully."
echo "Open GitHub Actions and download Periodic-v3-debug-apk after the build passes."
