package com.richardtalcott.periodic;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.Random;

public final class ElementDetailView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ElementData e;
    private final Random random;
    private final float[] particles = new float[180];
    private final long start = System.currentTimeMillis();

    private float atomRotationX = -12f;
    private float atomRotationY = 18f;
    private float atomScale = 1f;
    private float lastX, lastY, pinchDistance;
    private boolean moved;

    public ElementDetailView(Context context, ElementData element) {
        super(context);
        e = element;
        random = new Random(element.number * 37L);
        for (int i = 0; i < particles.length; i++) particles[i] = random.nextFloat();
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float t = (System.currentTimeMillis() - start) / 1000f;

        LinearGradient bg = new LinearGradient(
                0, 0, w, h,
                new int[]{Color.rgb(1,4,10), Color.rgb(4,14,26), Color.rgb(2,5,11)},
                null, Shader.TileMode.CLAMP);
        p.setShader(bg);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        drawAmbientParticles(c, w, h, t);

        float leftWidth = w * .24f;
        float rightStart = w * .73f;
        float atomCx = w * .49f;
        float atomCy = h * .49f;
        float atomRadius = Math.min(w * .21f, h * .40f) * atomScale;

        drawElementIdentity(c, leftWidth, h);
        drawInfoPanel(c, rightStart, w, h);
        drawAtom(c, atomCx, atomCy, atomRadius, t);

        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextSize(Math.min(w,h) * .018f);
        p.setColor(Color.rgb(105, 175, 215));
        c.drawText("DRAG TO ROTATE  •  PINCH TO ZOOM  •  SYSTEM BACK TO RETURN", atomCx, h - 16f, p);

        invalidate();
    }

    private void drawAmbientParticles(Canvas c, float w, float h, float t) {
        for (int i = 0; i < particles.length; i += 3) {
            float x = particles[i] * w;
            float y = (particles[i+1] * h + t * (5f + particles[i+2] * 9f)) % h;
            p.setColor(Color.argb(25 + (int)(particles[i+2] * 75), 115, 195, 245));
            c.drawCircle(x, y, .5f + particles[i+2] * 1.3f, p);
        }
    }

    private void drawElementIdentity(Canvas c, float panelWidth, float h) {
        RectF panel = new RectF(18f, 18f, panelWidth, h - 18f);
        drawGlassPanel(c, panel);

        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        p.setTextSize(h * .11f);
        p.setColor(Color.WHITE);
        p.setShadowLayer(14f, 0, 0, Color.rgb(60, 180, 255));
        c.drawText(e.symbol, panel.centerX(), h * .27f, p);
        p.clearShadowLayer();

        p.setTextSize(h * .045f);
        p.setColor(Color.rgb(220, 235, 245));
        c.drawText(e.name, panel.centerX(), h * .36f, p);

        p.setTextSize(h * .026f);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setColor(Color.rgb(91, 205, 255));
        c.drawText(e.category.toUpperCase(), panel.centerX(), h * .42f, p);

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(100, 90, 200, 255));
        c.drawRect(panel.left + 28f, h * .47f, panel.right - 28f, h * .476f, p);

        p.setTextSize(h * .028f);
        p.setColor(Color.rgb(170, 202, 222));
        c.drawText("ATOMIC NUMBER", panel.centerX(), h * .56f, p);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSize(h * .070f);
        p.setColor(Color.WHITE);
        c.drawText(String.valueOf(e.number), panel.centerX(), h * .67f, p);

        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextSize(h * .025f);
        p.setColor(Color.rgb(170, 202, 222));
        c.drawText("ATOMIC MASS", panel.centerX(), h * .75f, p);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSize(h * .045f);
        p.setColor(Color.WHITE);
        c.drawText(e.atomicMass, panel.centerX(), h * .83f, p);
    }

    private void drawInfoPanel(Canvas c, float left, float w, float h) {
        RectF panel = new RectF(left, 18f, w - 18f, h - 18f);
        drawGlassPanel(c, panel);

        int[] shells = ElementData.shells(e.number);
        String[] labels = {
                "PROTONS", "NEUTRONS", "ELECTRONS",
                "PERIOD", "GROUP", "SHELLS"
        };
        String[] values = {
                String.valueOf(e.number),
                String.valueOf(e.estimatedNeutrons),
                String.valueOf(e.number),
                String.valueOf(e.period),
                String.valueOf(e.group),
                shellText(shells)
        };

        float top = h * .16f;
        float rowGap = h * .12f;
        for (int i = 0; i < labels.length; i++) {
            float y = top + i * rowGap;
            p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
            p.setTextSize(h * .021f);
            p.setColor(Color.rgb(104, 185, 225));
            c.drawText(labels[i], panel.left + 22f, y, p);

            p.setTextAlign(Paint.Align.RIGHT);
            p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            p.setTextSize(h * .030f);
            p.setColor(Color.WHITE);
            c.drawText(values[i], panel.right - 22f, y, p);

            p.setColor(Color.argb(55, 105, 205, 255));
            c.drawRect(panel.left + 22f, y + 11f, panel.right - 22f, y + 13f, p);
        }
    }

    private void drawGlassPanel(Canvas c, RectF panel) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(115, 7, 18, 31));
        p.setShadowLayer(16f, 0f, 4f, Color.BLACK);
        c.drawRoundRect(panel, 18f, 18f, p);
        p.clearShadowLayer();

        LinearGradient glass = new LinearGradient(
                panel.left, panel.top, panel.right, panel.bottom,
                new int[]{Color.argb(80, 75, 180, 230), Color.argb(15, 20, 60, 90), Color.argb(55, 15, 55, 85)},
                null, Shader.TileMode.CLAMP);
        p.setShader(glass);
        c.drawRoundRect(panel, 18f, 18f, p);
        p.setShader(null);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f);
        p.setColor(Color.argb(150, 112, 215, 255));
        c.drawRoundRect(panel, 18f, 18f, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void drawAtom(Canvas c, float cx, float cy, float radius, float t) {
        RadialGradient halo = new RadialGradient(
                cx, cy, radius * 1.18f,
                new int[]{Color.argb(75, 30, 140, 235), Color.argb(18, 20, 70, 135), Color.TRANSPARENT},
                null, Shader.TileMode.CLAMP);
        p.setShader(halo);
        c.drawCircle(cx, cy, radius * 1.18f, p);
        p.setShader(null);

        int[] shells = ElementData.shells(e.number);
        int shellCount = 0;
        for (int v : shells) if (v > 0) shellCount++;

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.6f, radius * .006f));

        for (int s = 0; s < shellCount; s++) {
            float rr = radius * (.30f + .70f * (s + 1f) / shellCount);
            float squash = .52f + .08f * (float)Math.sin(Math.toRadians(atomRotationX + s * 20f));
            c.save();
            c.rotate(atomRotationY + s * 16f, cx, cy);
            RectF oval = new RectF(cx - rr, cy - rr * squash, cx + rr, cy + rr * squash);
            p.setColor(Color.argb(100, 95, 195, 255));
            p.setShadowLayer(7f, 0f, 0f, Color.rgb(50, 155, 255));
            c.drawOval(oval, p);

            int count = shells[s];
            int visible = Math.min(count, 18);
            for (int i = 0; i < visible; i++) {
                double a = Math.PI * 2 * i / visible + t * (.62f + s * .09f) * (s % 2 == 0 ? 1 : -1);
                float ex = cx + (float)Math.cos(a) * rr;
                float ey = cy + (float)Math.sin(a) * rr * squash;
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.rgb(87, 212, 255));
                p.setShadowLayer(12f, 0f, 0f, Color.rgb(65, 195, 255));
                c.drawCircle(ex, ey, Math.max(3.2f, radius * .015f), p);
                p.setStyle(Paint.Style.STROKE);
            }
            p.clearShadowLayer();
            c.restore();
        }

        p.setStyle(Paint.Style.FILL);
        int nucleons = Math.min(42, Math.max(4, e.number + e.estimatedNeutrons));
        float nucleusRadius = radius * .18f;
        for (int i = 0; i < nucleons; i++) {
            double a = i * 2.399963 + t * .13;
            float ring = (float)Math.sqrt((i + .7f) / nucleons) * nucleusRadius;
            float nx = cx + (float)Math.cos(a + Math.toRadians(atomRotationY)) * ring;
            float ny = cy + (float)Math.sin(a + Math.toRadians(atomRotationX)) * ring * .76f;
            boolean proton = i % 2 == 0;
            int color = proton ? Color.rgb(255, 68, 94) : Color.rgb(67, 142, 255);
            p.setColor(color);
            p.setShadowLayer(10f, 0f, 0f, color);
            c.drawCircle(nx, ny, Math.max(5f, radius * .035f), p);
        }
        p.clearShadowLayer();
    }

    @Override public boolean onTouchEvent(MotionEvent ev) {
        if (ev.getPointerCount() == 2) {
            float dx = ev.getX(0) - ev.getX(1);
            float dy = ev.getY(0) - ev.getY(1);
            float distance = (float)Math.hypot(dx, dy);
            if (ev.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
                pinchDistance = distance;
            } else if (ev.getActionMasked() == MotionEvent.ACTION_MOVE && pinchDistance > 0f) {
                atomScale = Math.max(.70f, Math.min(1.45f, atomScale * distance / pinchDistance));
                pinchDistance = distance;
                invalidate();
            }
            return true;
        }

        float x = ev.getX(), y = ev.getY();
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            lastX = x;
            lastY = y;
            moved = false;
            return true;
        }
        if (ev.getActionMasked() == MotionEvent.ACTION_MOVE) {
            float dx = x - lastX, dy = y - lastY;
            if (Math.abs(dx) + Math.abs(dy) > 4f) moved = true;
            atomRotationY += dx * .28f;
            atomRotationX += dy * .28f;
            lastX = x;
            lastY = y;
            invalidate();
            return true;
        }
        return true;
    }

    private String shellText(int[] shells) {
        StringBuilder b = new StringBuilder();
        for (int v : shells) {
            if (v == 0) break;
            if (b.length() > 0) b.append(" • ");
            b.append(v);
        }
        return b.toString();
    }
}
