package com.richardtalcott.periodic;

import android.content.*;
import android.graphics.*;
import android.view.*;
import java.util.*;

public final class PeriodicTableView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<RectF> cells = new ArrayList<>();
    private final ArrayList<Integer> nums = new ArrayList<>();
    private final float[] stars = new float[240];
    private final Random random = new Random(24);

    private float scale = 1f;
    private float offX = 0f, offY = 0f;
    private float lastX, lastY, pinchDistance;
    private float velocityX, velocityY;
    private boolean moved, pinching;
    private long lastMoveTime;
    private int pressedElement = -1;
    private long pressTime;

    public PeriodicTableView(Context context) {
        super(context);
        for (int i = 0; i < stars.length; i++) stars[i] = random.nextFloat();
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float t = System.currentTimeMillis() / 1000f;

        LinearGradient bg = new LinearGradient(
                0, 0, w, h,
                new int[]{Color.rgb(1,4,9), Color.rgb(4,13,24), Color.rgb(1,5,11)},
                null, Shader.TileMode.CLAMP);
        p.setShader(bg);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        for (int i = 0; i < stars.length; i += 3) {
            p.setColor(Color.argb(35 + (int)(stars[i+2] * 95), 150, 210, 255));
            c.drawCircle(stars[i] * w, stars[i+1] * h, .4f + stars[i+2] * 1.2f, p);
        }

        RadialGradient tableGlow = new RadialGradient(
                w*.5f, h*.50f, w*.52f,
                new int[]{Color.argb(60, 20, 120, 200), Color.TRANSPARENT},
                null, Shader.TileMode.CLAMP);
        p.setShader(tableGlow);
        c.drawOval(new RectF(w*.05f, h*.12f, w*.95f, h*.94f), p);
        p.setShader(null);

        c.save();
        c.translate(offX, offY);
        c.scale(scale, scale);

        float pad = 20f;
        float header = 24f;
        float cw = (w - pad * 2f) / 18f;
        float ch = Math.min(70f, (h - header - 20f) / 9f);

        cells.clear();
        nums.clear();

        for (int n = 1; n <= 118; n++) {
            ElementData e = ElementData.byNumber(n);
            float left = pad + (e.group - 1) * cw;
            float top = header + (e.row - 1) * ch;
            RectF r = new RectF(left + 2.5f, top + 2.5f, left + cw - 2.5f, top + ch - 2.5f);
            cells.add(r);
            nums.add(n);
            drawTile(c, r, e, n == pressedElement, ch);
        }

        c.restore();

        if (Math.abs(velocityX) > .05f || Math.abs(velocityY) > .05f) {
            offX += velocityX;
            offY += velocityY;
            velocityX *= .91f;
            velocityY *= .91f;
            clampOffsets(w, h);
            postInvalidateOnAnimation();
        }
    }

    private void drawTile(Canvas c, RectF r, ElementData e, boolean pressed, float ch) {
        int base = color(e.category);
        float depth = Math.max(2.5f, r.height() * .08f);

        RectF shadow = new RectF(r.left + depth, r.top + depth, r.right + depth, r.bottom + depth);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(150, 0, 0, 0));
        p.setShadowLayer(8f, 2f, 4f, Color.BLACK);
        c.drawRoundRect(shadow, 8f, 8f, p);
        p.clearShadowLayer();

        LinearGradient face = new LinearGradient(
                r.left, r.top, r.right, r.bottom,
                new int[]{
                        blend(base, Color.WHITE, .20f),
                        base,
                        blend(base, Color.BLACK, .42f)
                },
                null, Shader.TileMode.CLAMP);
        p.setShader(face);
        if (pressed) {
            RectF inset = new RectF(r.left + 2f, r.top + 2f, r.right - 2f, r.bottom - 2f);
            c.drawRoundRect(inset, 7f, 7f, p);
        } else {
            c.drawRoundRect(r, 7f, 7f, p);
        }
        p.setShader(null);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f);
        p.setColor(Color.argb(205, 185, 230, 255));
        p.setShadowLayer(6f, 0f, 0f, Color.argb(150, 75, 185, 255));
        c.drawRoundRect(r, 7f, 7f, p);
        p.clearShadowLayer();

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(75, 255, 255, 255));
        c.drawRoundRect(new RectF(r.left+3f, r.top+3f, r.right-3f, r.top+Math.max(5f, r.height()*.10f)), 4f, 4f, p);

        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSize(Math.max(8f, ch * .16f));
        p.setColor(Color.rgb(205, 232, 248));
        c.drawText(String.valueOf(e.number), r.left + 5f, r.top + 13f, p);

        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(Math.max(14f, ch * .37f));
        p.setColor(Color.WHITE);
        p.setShadowLayer(5f, 0f, 1f, Color.BLACK);
        c.drawText(e.symbol, r.centerX(), r.centerY() + 6f, p);
        p.clearShadowLayer();

        if (scale > 1.18f) {
            p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
            p.setTextSize(Math.max(6f, ch * .11f));
            p.setColor(Color.rgb(195, 218, 232));
            c.drawText(e.name, r.centerX(), r.bottom - 6f, p);
        }
    }

    private int blend(int a, int b, float amount) {
        return Color.rgb(
                (int)(Color.red(a) + (Color.red(b) - Color.red(a)) * amount),
                (int)(Color.green(a) + (Color.green(b) - Color.green(a)) * amount),
                (int)(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * amount));
    }

    private int color(String cat) {
        if (cat.contains("Noble")) return Color.rgb(34, 72, 128);
        if (cat.contains("Halogen")) return Color.rgb(100, 39, 94);
        if (cat.contains("Alkali")) return Color.rgb(122, 43, 53);
        if (cat.contains("Transition")) return Color.rgb(22, 79, 111);
        if (cat.contains("Lanthanide")) return Color.rgb(80, 45, 118);
        if (cat.contains("Actinide")) return Color.rgb(111, 38, 78);
        if (cat.equals("Nonmetal")) return Color.rgb(20, 99, 82);
        if (cat.equals("Metalloid")) return Color.rgb(95, 88, 29);
        return Color.rgb(47, 63, 82);
    }

    @Override public boolean onTouchEvent(MotionEvent ev) {
        if (ev.getPointerCount() == 2) {
            float dx = ev.getX(0) - ev.getX(1);
            float dy = ev.getY(0) - ev.getY(1);
            float distance = (float)Math.hypot(dx, dy);

            if (ev.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
                pinchDistance = distance;
                pinching = true;
                velocityX = velocityY = 0f;
            } else if (ev.getActionMasked() == MotionEvent.ACTION_MOVE && pinchDistance > 0f) {
                float newScale = Math.max(.78f, Math.min(3.0f, scale * distance / pinchDistance));
                float focusX = (ev.getX(0) + ev.getX(1)) * .5f;
                float focusY = (ev.getY(0) + ev.getY(1)) * .5f;
                float ratio = newScale / scale;
                offX = focusX - (focusX - offX) * ratio;
                offY = focusY - (focusY - offY) * ratio;
                scale = newScale;
                pinchDistance = distance;
                clampOffsets(getWidth(), getHeight());
                invalidate();
            }
            return true;
        }

        float x = ev.getX(), y = ev.getY();

        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            lastX = x;
            lastY = y;
            moved = false;
            pinching = false;
            velocityX = velocityY = 0f;
            lastMoveTime = System.currentTimeMillis();
            pressedElement = hitElement(x, y);
            pressTime = System.currentTimeMillis();
            invalidate();
            return true;
        }

        if (ev.getActionMasked() == MotionEvent.ACTION_MOVE) {
            float dx = x - lastX, dy = y - lastY;
            if (Math.abs(dx) + Math.abs(dy) > 5f) {
                moved = true;
                pressedElement = -1;
            }

            long now = System.currentTimeMillis();
            float dt = Math.max(1f, now - lastMoveTime);
            velocityX = dx * 16f / dt;
            velocityY = dy * 16f / dt;
            offX += dx;
            offY += dy;
            lastX = x;
            lastY = y;
            lastMoveTime = now;
            clampOffsets(getWidth(), getHeight());
            invalidate();
            return true;
        }

        if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
            int hit = hitElement(x, y);
            if (!moved && !pinching && hit > 0 && hit == pressedElement) {
                Intent intent = new Intent(getContext(), ElementDetailActivity.class);
                intent.putExtra("atomicNumber", hit);
                getContext().startActivity(intent);
            }
            pressedElement = -1;
            invalidate();
            return true;
        }

        if (ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            pressedElement = -1;
            invalidate();
        }
        return true;
    }

    private int hitElement(float x, float y) {
        float tx = (x - offX) / scale;
        float ty = (y - offY) / scale;
        for (int i = 0; i < cells.size(); i++) {
            if (cells.get(i).contains(tx, ty)) return nums.get(i);
        }
        return -1;
    }

    private void clampOffsets(float w, float h) {
        float maxX = w * .45f * scale;
        float maxY = h * .45f * scale;
        offX = Math.max(-maxX, Math.min(maxX, offX));
        offY = Math.max(-maxY, Math.min(maxY, offY));
    }
}
