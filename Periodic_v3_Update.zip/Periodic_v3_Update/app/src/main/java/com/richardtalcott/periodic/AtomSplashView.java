package com.richardtalcott.periodic;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.Random;

public final class AtomSplashView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random(8);
    private final float[] stars = new float[360];
    private final long start = System.currentTimeMillis();

    public AtomSplashView(Context context) {
        super(context);
        for (int i = 0; i < stars.length; i++) stars[i] = random.nextFloat();
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float t = (System.currentTimeMillis() - start) / 1000f;

        LinearGradient bg = new LinearGradient(
                0, 0, w, h,
                new int[]{Color.rgb(1,4,10), Color.rgb(5,14,27), Color.rgb(2,5,11)},
                null, Shader.TileMode.CLAMP);
        p.setShader(bg);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        for (int i = 0; i < stars.length; i += 3) {
            float pulse = .55f + .45f * (float)Math.sin(t * 1.7f + i);
            p.setColor(Color.argb((int)(55 + 170 * stars[i+2] * pulse), 180, 225, 255));
            c.drawCircle(stars[i] * w, stars[i+1] * h, .6f + stars[i+2] * 1.8f, p);
        }

        float cx = w * .38f;
        float cy = h * .48f;
        float radius = Math.min(w, h) * .30f;

        RadialGradient halo = new RadialGradient(
                cx, cy, radius * 1.25f,
                new int[]{Color.argb(115, 35, 155, 255), Color.argb(25, 20, 70, 135), Color.TRANSPARENT},
                null, Shader.TileMode.CLAMP);
        p.setShader(halo);
        c.drawCircle(cx, cy, radius * 1.25f, p);
        p.setShader(null);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2.2f, h * .005f));
        int[] orbitColors = {
                Color.rgb(86, 214, 255),
                Color.rgb(255, 79, 116),
                Color.rgb(215, 235, 255)
        };

        for (int orbit = 0; orbit < 3; orbit++) {
            float rotation = orbit * 58f + 18f + t * (orbit % 2 == 0 ? 4f : -3f);
            c.save();
            c.rotate(rotation, cx, cy);
            RectF oval = new RectF(cx-radius, cy-radius*.34f, cx+radius, cy+radius*.34f);
            p.setColor(Color.argb(145, Color.red(orbitColors[orbit]), Color.green(orbitColors[orbit]), Color.blue(orbitColors[orbit])));
            p.setShadowLayer(12f, 0, 0, orbitColors[orbit]);
            c.drawOval(oval, p);

            double a = t * (1.35 + orbit * .17) + orbit * 2.2;
            float ex = cx + (float)Math.cos(a) * radius;
            float ey = cy + (float)Math.sin(a) * radius * .34f;

            p.setStyle(Paint.Style.FILL);
            p.setColor(orbitColors[orbit]);
            p.setShadowLayer(20f, 0, 0, orbitColors[orbit]);
            c.drawCircle(ex, ey, Math.max(6f, h * .013f), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            c.restore();
        }

        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 16; i++) {
            double a = i * 2.399963 + t * .15;
            float rr = (i % 4) * h * .010f;
            float nx = cx + (float)Math.cos(a) * rr;
            float ny = cy + (float)Math.sin(a) * rr;
            int color = (i % 2 == 0) ? Color.rgb(255, 70, 96) : Color.rgb(73, 151, 255);
            p.setColor(color);
            p.setShadowLayer(14f, 0, 0, color);
            c.drawCircle(nx, ny, Math.max(7f, h * .016f), p);
        }
        p.clearShadowLayer();

        float panelLeft = w * .62f;
        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setColor(Color.WHITE);
        p.setTextSize(Math.min(w, h) * .12f);
        p.setShadowLayer(18f, 0, 0, Color.rgb(55, 170, 255));
        c.drawText("PERIODIC", panelLeft, h * .46f, p);
        p.clearShadowLayer();

        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextSize(Math.min(w, h) * .034f);
        p.setColor(Color.rgb(115, 210, 255));
        c.drawText("INTERACTIVE ATOMIC LABORATORY", panelLeft + 3, h * .53f, p);

        p.setColor(Color.argb(120, 105, 205, 255));
        c.drawRect(panelLeft, h * .575f, w * .91f, h * .581f, p);

        p.setTextSize(Math.min(w, h) * .023f);
        p.setColor(Color.rgb(175, 205, 225));
        c.drawText("ELEMENTS  •  ATOMS  •  MATTER", panelLeft + 3, h * .64f, p);

        invalidate();
    }
}
