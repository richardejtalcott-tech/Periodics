Periodic v3 visual update

This patch keeps the app focused on exactly three experiences:
1. Landscape splash screen
2. Full-screen periodic table with no side or bottom controls
3. Landscape element detail interface

Apply only from the v3-development branch:
bash Periodic_v3_Update/APPLY_V3.sh
