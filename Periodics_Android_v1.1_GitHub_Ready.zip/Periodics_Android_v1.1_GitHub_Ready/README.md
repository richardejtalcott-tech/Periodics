# Periodics Android v1.1

A native Android application with an animated atom loading screen, interactive periodic table, and element detail pages.

## One-command Codespaces build

From the repository root, run:

```bash
chmod +x build-apk.sh gradlew && ./build-apk.sh
```

The script pins the build to Java 17, installs the required Android SDK packages when missing, runs a clean build, unit tests and lint, and produces:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

The included workflow builds automatically after a push to `main` or `master`, and can also be started manually from the **Actions** tab. Download the finished APK from the `Periodics-debug-apk` artifact.

## Pinned build compatibility

- Java/JDK: 17
- Android Gradle Plugin: 8.13.2
- Gradle: 8.13
- compileSdk/targetSdk: 35
- build-tools: 35.0.0
- minSdk: 26
- AndroidX AppCompat: 1.7.1
- AndroidX Core: 1.16.0

No API keys or signing secrets are required for the debug APK.
