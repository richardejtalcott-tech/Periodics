#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

say() { printf '\n==> %s\n' "$*"; }

# Keep every part of the build on Java 17.
if ! java -version 2>&1 | head -n1 | grep -q '"17\.'; then
  if command -v apt-get >/dev/null 2>&1; then
    say "Installing Java 17"
    sudo apt-get update -y
    sudo apt-get install -y openjdk-17-jdk curl unzip
  else
    echo "Java 17 is required. Current version:" >&2
    java -version >&2 || true
    exit 1
  fi
fi

JAVA17_HOME=$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")
if [ ! -x "$JAVA17_HOME/bin/java" ] || ! "$JAVA17_HOME/bin/java" -version 2>&1 | head -n1 | grep -q '"17\.'; then
  JAVA17_HOME=$(dirname "$(dirname "$(readlink -f "$(update-alternatives --list javac | grep 'java-17' | head -n1)")")")
fi
export JAVA_HOME="$JAVA17_HOME"
export PATH="$JAVA_HOME/bin:$PATH"

say "Using Java"
java -version

# Codespaces do not always include the Android SDK. Install a pinned SDK when absent.
if [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  if [ -n "${ANDROID_HOME:-}" ]; then
    export ANDROID_SDK_ROOT="$ANDROID_HOME"
  else
    export ANDROID_SDK_ROOT="$HOME/android-sdk"
  fi
fi
export ANDROID_HOME="$ANDROID_SDK_ROOT"
export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:$PATH"

if ! command -v sdkmanager >/dev/null 2>&1; then
  say "Installing Android command-line tools"
  mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
  TMP_ZIP=$(mktemp --suffix=.zip)
  curl -fL --retry 3 -o "$TMP_ZIP" "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  TMP_DIR=$(mktemp -d)
  unzip -q "$TMP_ZIP" -d "$TMP_DIR"
  rm -rf "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  mv "$TMP_DIR/cmdline-tools" "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  rm -rf "$TMP_DIR" "$TMP_ZIP"
fi

say "Installing required Android SDK packages"
yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"

say "Stopping old Gradle daemons"
./gradlew --stop || true

say "Running clean, compile, unit tests, lint, and APK build"
./gradlew --no-daemon --stacktrace clean assembleDebug testDebugUnitTest lintDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
test -f "$APK"
SHA=$(sha256sum "$APK" | awk '{print $1}')
printf '\nSUCCESS\nAPK: %s\nSHA-256: %s\n' "$APK" "$SHA"
