package com.richardtalcott.periodics;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public final class MainActivity extends AppCompatActivity implements PeriodicTableView.Listener {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PeriodicTableView view = new PeriodicTableView(this);
        view.setListener(this);
        setContentView(view);
    }

    @Override public void onElementSelected(Element element) {
        Intent intent = new Intent(this, ElementDetailActivity.class);
        intent.putExtra("atomicNumber", element.atomicNumber());
        startActivity(intent);
    }
}
