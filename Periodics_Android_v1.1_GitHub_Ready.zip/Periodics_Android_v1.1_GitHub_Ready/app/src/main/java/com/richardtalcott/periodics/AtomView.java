package com.richardtalcott.periodics;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.Random;

public final class AtomView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final boolean splash;
    private float angle;
    private final float[] stars = new float[120];

    public AtomView(Context context, boolean splash) {
        super(context); this.splash = splash;
        Random r = new Random(42);
        for (int i=0;i<stars.length;i++) stars[i]=r.nextFloat();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); float w=getWidth(), h=getHeight();
        p.setShader(new LinearGradient(0,0,w,h,Color.rgb(4,10,25),Color.rgb(8,42,75),Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        p.setColor(Color.argb(150,220,240,255));
        for(int i=0;i<stars.length;i+=2) c.drawCircle(stars[i]*w,stars[i+1]*h,1+(i%3),p);
        float cx=w*.5f, cy=h*.46f, radius=Math.min(w,h)*.22f;
        drawOrbit(c,cx,cy,radius,0); drawOrbit(c,cx,cy,radius,60); drawOrbit(c,cx,cy,radius,-60);
        for(int i=0;i<14;i++) {
            double a=i*Math.PI*2/14; float x=cx+(float)Math.cos(a)*radius*.25f; float y=cy+(float)Math.sin(a)*radius*.2f;
            p.setColor(i%2==0?Color.rgb(255,70,90):Color.rgb(65,205,255)); c.drawCircle(x,y,radius*.085f,p);
        }
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); p.setColor(Color.WHITE);
        p.setTextSize(Math.min(w,h)*.07f); c.drawText("PERIODICS",cx,h*.80f,p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(Math.min(w,h)*.027f); p.setColor(Color.rgb(150,225,255));
        c.drawText("Explore the building blocks of matter",cx,h*.87f,p);
        angle += 2.4f; postInvalidateOnAnimation();
    }

    private void drawOrbit(Canvas c,float cx,float cy,float r,float rotation){
        c.save(); c.rotate(rotation,cx,cy); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.argb(170,100,220,255));
        RectF oval=new RectF(cx-r,cy-r*.40f,cx+r,cy+r*.40f); c.drawOval(oval,p); p.setStyle(Paint.Style.FILL);
        double a=Math.toRadians(angle+rotation*2); float ex=cx+(float)Math.cos(a)*r; float ey=cy+(float)Math.sin(a)*r*.40f;
        p.setColor(Color.WHITE); c.drawCircle(ex,ey,r*.055f,p); c.restore();
    }
}
