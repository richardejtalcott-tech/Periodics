package com.richardtalcott.periodics;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;

public final class ElementDetailView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Element element;
    private Runnable exploreAction;
    private float angle;
    private final RectF button = new RectF();

    public ElementDetailView(Context context, Element element){super(context);this.element=element;}
    public void setExploreAction(Runnable action){exploreAction=action;}

    @Override protected void onDraw(Canvas c){
        float w=getWidth(),h=getHeight();
        p.setShader(new LinearGradient(0,0,w,h,Color.rgb(4,12,28),Color.rgb(10,42,67),Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
        p.setColor(Color.argb(90,100,190,240));for(int i=0;i<10;i++)c.drawLine(0,h*(.1f+i*.09f),w,h*(.1f+i*.09f),p);
        float cx=w*.23f,cy=h*.48f,r=Math.min(w,h)*.23f;
        drawOrbit(c,cx,cy,r,0);drawOrbit(c,cx,cy,r,60);drawOrbit(c,cx,cy,r,-60);
        int nucleons=Math.min(22,Math.max(4,element.atomicNumber()/3));
        for(int i=0;i<nucleons;i++){double a=i*2.399;float rr=(i%5)*r*.035f;float x=cx+(float)Math.cos(a)*rr,y=cy+(float)Math.sin(a)*rr;p.setColor(i%2==0?Color.rgb(255,75,90):Color.rgb(60,195,255));c.drawCircle(x,y,r*.055f,p);}

        float panelX=w*.47f;
        p.setTextAlign(Paint.Align.LEFT);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setColor(Color.WHITE);p.setTextSize(h*.12f);c.drawText(element.symbol(),panelX,h*.22f,p);
        p.setTextSize(h*.055f);p.setColor(Color.rgb(115,220,255));c.drawText(element.name(),panelX,h*.30f,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(h*.030f);p.setColor(Color.LTGRAY);c.drawText("Atomic number  "+element.atomicNumber(),panelX,h*.38f,p);c.drawText("Category  "+element.category(),panelX,h*.44f,p);
        p.setTextSize(h*.027f);wrap(c,element.summary(),panelX,h*.54f,w*.42f,h*.043f);

        p.setColor(Color.rgb(115,125,140));RectF sample=new RectF(w*.72f,h*.56f,w*.89f,h*.76f);c.drawRoundRect(sample,18,18,p);
        p.setColor(Color.argb(120,255,255,255));c.drawOval(new RectF(sample.left+15,sample.top+12,sample.right-15,sample.top+45),p);
        p.setTextAlign(Paint.Align.CENTER);p.setTextSize(h*.023f);p.setColor(Color.WHITE);c.drawText("Real-world sample",sample.centerX(),sample.bottom+h*.045f,p);

        button.set(panelX,h*.78f,w*.66f,h*.90f);p.setColor(Color.rgb(20,155,200));c.drawRoundRect(button,18,18,p);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextSize(h*.035f);c.drawText("EXPLORE",button.centerX(),button.centerY()+h*.012f,p);p.setTypeface(Typeface.DEFAULT);
        angle+=2.2f;postInvalidateOnAnimation();
    }
    private void drawOrbit(Canvas c,float cx,float cy,float r,float rot){c.save();c.rotate(rot,cx,cy);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.argb(170,90,215,255));RectF o=new RectF(cx-r,cy-r*.42f,cx+r,cy+r*.42f);c.drawOval(o,p);p.setStyle(Paint.Style.FILL);double a=Math.toRadians(angle+rot*2);float ex=cx+(float)Math.cos(a)*r,ey=cy+(float)Math.sin(a)*r*.42f;p.setColor(Color.WHITE);c.drawCircle(ex,ey,r*.045f,p);c.restore();}
    private void wrap(Canvas c,String text,float x,float y,float max,float line){String[] words=text.split(" ");StringBuilder b=new StringBuilder();for(String word:words){String test=b.length()==0?word:b+" "+word;if(p.measureText(test)>max){c.drawText(b.toString(),x,y,p);y+=line;b=new StringBuilder(word);}else{if(b.length()>0)b.append(' ');b.append(word);}}if(b.length()>0)c.drawText(b.toString(),x,y,p);}
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_UP&&button.contains(e.getX(),e.getY())){if(exploreAction!=null)exploreAction.run();return true;}return true;}
}
