package com.richardtalcott.periodics;

/** Immutable element data model that avoids Java record runtime requirements on older Android versions. */
public final class Element {
    private final int atomicNumber;
    private final String symbol;
    private final String name;
    private final String category;
    private final String summary;

    public Element(int atomicNumber, String symbol, String name, String category, String summary) {
        this.atomicNumber = atomicNumber;
        this.symbol = symbol;
        this.name = name;
        this.category = category;
        this.summary = summary;
    }

    public int atomicNumber() { return atomicNumber; }
    public String symbol() { return symbol; }
    public String name() { return name; }
    public String category() { return category; }
    public String summary() { return summary; }
}
