package com.richardtalcott.periodics;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public final class ElementDetailActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int number = Math.max(1, Math.min(118, getIntent().getIntExtra("atomicNumber", 1)));
        Element element = ElementRepository.byNumber(number);
        ElementDetailView view = new ElementDetailView(this, element);
        view.setExploreAction(() -> Toast.makeText(this, "Expanded Explore pages are planned for the next release.", Toast.LENGTH_LONG).show());
        setContentView(view);
    }
}
