package com.richardtalcott.periodics;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.util.List;

public final class PeriodicTableView extends View {
    public interface Listener { void onElementSelected(Element element); }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Element> elements = ElementRepository.all();
    private final ScaleGestureDetector scaler;
    private Listener listener;
    private float scale=1f, offsetX=0, offsetY=0, lastX, lastY;
    private boolean dragging;

    public PeriodicTableView(Context context) {
        super(context);
        scaler = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                scale = Math.max(.65f, Math.min(2.5f, scale*d.getScaleFactor()));
                invalidate(); return true;
            }
        });
    }
    public void setListener(Listener l){listener=l;}

    @Override protected void onDraw(Canvas c){
        float w=getWidth(), h=getHeight();
        p.setShader(new LinearGradient(0,0,0,h,Color.rgb(5,14,30),Color.rgb(12,35,58),Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
        drawRoom(c,w,h);
        p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); p.setColor(Color.WHITE); p.setTextSize(h*.075f); c.drawText("PERIODICS",w*.055f,h*.11f,p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(h*.032f); p.setColor(Color.rgb(105,215,255)); c.drawText("Explore the elements",w*.058f,h*.16f,p);

        c.save(); c.translate(offsetX,offsetY); c.scale(scale,scale,w/2,h/2);
        float tableW=w*.86f, cell=tableW/18f, startX=(w-tableW)/2f, startY=h*.25f;
        for(Element e:elements){
            int[] pos=position(e.atomicNumber());
            float x=startX+pos[0]*cell, y=startY+pos[1]*cell*.92f;
            drawCell(c,e,x,y,cell*.92f,cell*.82f);
        }
        c.restore();
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(h*.022f); p.setColor(Color.argb(190,220,240,255)); c.drawText("Pinch to zoom • Drag to move • Tap an element",w/2,h*.96f,p);
    }

    private void drawRoom(Canvas c,float w,float h){
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.argb(80,80,180,240));
        c.drawLine(0,h*.2f,w*.12f,h*.28f,p); c.drawLine(w,h*.2f,w*.88f,h*.28f,p); c.drawLine(w*.12f,h*.28f,w*.12f,h*.9f,p); c.drawLine(w*.88f,h*.28f,w*.88f,h*.9f,p);
        for(int i=0;i<8;i++) c.drawLine(0,h*(.25f+i*.09f),w,h*(.25f+i*.09f),p); p.setStyle(Paint.Style.FILL);
    }
    private void drawCell(Canvas c,Element e,float x,float y,float cw,float ch){
        int base = switch(e.category()) {
            case "Noble gas" -> Color.rgb(70,90,190);
            case "Halogen" -> Color.rgb(25,155,170);
            case "Alkali metal" -> Color.rgb(180,70,75);
            case "Alkaline earth metal" -> Color.rgb(195,120,45);
            case "Lanthanide" -> Color.rgb(105,70,160);
            case "Actinide" -> Color.rgb(145,55,120);
            case "Nonmetal" -> Color.rgb(45,145,95);
            default -> Color.rgb(45,95,145);
        };
        p.setColor(Color.argb(225,Color.red(base),Color.green(base),Color.blue(base))); c.drawRoundRect(x,y,x+cw,y+ch,8,8,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.argb(180,180,235,255)); c.drawRoundRect(x,y,x+cw,y+ch,8,8,p); p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.WHITE); p.setTextSize(ch*.20f); c.drawText(String.valueOf(e.atomicNumber()),x+cw*.08f,y+ch*.23f,p);
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); p.setTextSize(ch*.42f); c.drawText(e.symbol(),x+cw*.5f,y+ch*.64f,p); p.setTypeface(Typeface.DEFAULT);
    }

    @Override public boolean onTouchEvent(MotionEvent ev){
        scaler.onTouchEvent(ev);
        switch(ev.getActionMasked()){
            case MotionEvent.ACTION_DOWN -> {lastX=ev.getX(); lastY=ev.getY(); dragging=false; return true;}
            case MotionEvent.ACTION_MOVE -> {if(!scaler.isInProgress()){float dx=ev.getX()-lastX,dy=ev.getY()-lastY; if(Math.abs(dx)+Math.abs(dy)>5)dragging=true; offsetX+=dx;offsetY+=dy;lastX=ev.getX();lastY=ev.getY();invalidate();} return true;}
            case MotionEvent.ACTION_UP -> {if(!dragging && !scaler.isInProgress()) handleTap(ev.getX(),ev.getY()); return true;}
        }
        return true;
    }
    private void handleTap(float sx,float sy){
        float w=getWidth(),h=getHeight(),tableW=w*.86f,cell=tableW/18f,startX=(w-tableW)/2f,startY=h*.25f;
        float x=(sx-offsetX-w/2)/scale+w/2, y=(sy-offsetY-h/2)/scale+h/2;
        for(Element e:elements){int[] pos=position(e.atomicNumber()); float left=startX+pos[0]*cell,top=startY+pos[1]*cell*.92f; if(x>=left&&x<=left+cell*.92f&&y>=top&&y<=top+cell*.82f){if(listener!=null)listener.onElementSelected(e);return;}}
    }
    private static int[] position(int z){
        int[][] rows={{1,18},{1,2,13,14,15,16,17,18},{1,2,13,14,15,16,17,18},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18},{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18}};
        if(z==1)return new int[]{0,0}; if(z==2)return new int[]{17,0};
        if(z>=3&&z<=10){int[] g={0,1,12,13,14,15,16,17};return new int[]{g[z-3],1};}
        if(z>=11&&z<=18){int[] g={0,1,12,13,14,15,16,17};return new int[]{g[z-11],2};}
        if(z>=19&&z<=36)return new int[]{z-19,3};
        if(z>=37&&z<=54)return new int[]{z-37,4};
        if(z==55)return new int[]{0,5}; if(z==56)return new int[]{1,5}; if(z>=72&&z<=86)return new int[]{z-69,5};
        if(z==87)return new int[]{0,6}; if(z==88)return new int[]{1,6}; if(z>=104&&z<=118)return new int[]{z-101,6};
        if(z>=57&&z<=71)return new int[]{z-55,7};
        return new int[]{z-87,8};
    }
}
